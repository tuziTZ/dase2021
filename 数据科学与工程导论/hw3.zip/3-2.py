import math
print(pow(27,1/3.0))
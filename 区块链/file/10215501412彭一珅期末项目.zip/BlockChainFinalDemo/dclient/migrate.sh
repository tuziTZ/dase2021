rm -rf ./src/assets/contracts/*
cp ../dserver/build/contracts/* ./src/assets/contracts/
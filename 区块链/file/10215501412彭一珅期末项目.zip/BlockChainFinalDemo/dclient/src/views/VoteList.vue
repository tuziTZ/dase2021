<template>
    <div class="container">
        <div class="carousel-container">
            <n-carousel autoplay class="carousel" :dot-type="'line'" style="height: 180px">
                <img class="carousel-img" src="https://image-assets.mihuashi.com/artwork-carousel/5.jpg">
                <img class="carousel-img" src="https://image-assets.mihuashi.com/artwork-carousel/2.jpg">
                <img class="carousel-img" src="https://image-assets.mihuashi.com/artwork-carousel/3.jpg">
                <img class="carousel-img" src="https://image-assets.mihuashi.com/artwork-carousel/4.jpg">
            </n-carousel>
        </div>

        <div class="post-container">
            <n-button @click="showPostModal" class="post-button" size="large" strong secondary circle type="primary">
                Create a Vote
            </n-button>

            <n-modal v-model:show="postModalFlag" :style="{ width: '600px' }" preset="card" size="huge"
                :bordered="false">
                <n-form ref="formRef" :model="post_comission" label-placement="left" label-width="auto"
                    require-mark-placement="right-hanging">
                    <n-form-item label="title" path="inputValue">
                        <n-input v-model:value="post_comission.title" placeholder="Title" />
                    </n-form-item>
                    <n-form-item label="discription" path="textareaValue">
                        <n-input v-model:value="post_comission.description" placeholder="discription" type="textarea" :autosize="{
                            minRows: 3,
                            maxRows: 5
                        }" />
                    </n-form-item>
                    <n-form-item label="maxParticipants" path="inputValue">
                        <n-input-number v-model:value="post_comission.maxParticipants" placeholder="Num of Voter" />
                    </n-form-item>
                    <n-form-item label="duration" path="inputNumberValue">
                        <n-input-number v-model:value="post_comission.duration" placeholder="Duration/s" />
                        <!-- <div>&nbsp;&nbsp; × 1e12 Wei(ETH-6)</div> -->
                    </n-form-item>
                    <n-form-item label="reward" path="inputValue">
                        <n-input-number v-model:value="post_comission.reward" placeholder="Reward for Winner" />
                        <div>&nbsp;&nbsp; × 1e12 Wei(ETH-6)</div>
                    </n-form-item>
                    
                    <div style="display: flex; justify-content: flex-end">
                        <n-button round type="primary" @click="postSubmit">
                            Submit
                        </n-button>
                    </div>
                </n-form>
            </n-modal>
        </div>

        <div class="content-container">
            <n-grid :x-gap="12" :y-gap="8" :cols="4">
                <n-gi v-for="comission in votings" :key="comission.voteId">
                    <CardVue :title="comission.title" :endTime="comission.endTime" :reward="comission.reward"
                        :img="comission.img" @click="purchase(comission)"></CardVue>
                </n-gi>
            </n-grid>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import Web3 from 'web3';
import {
    NCarousel, NCarouselItem,
    NButton, NModal, NForm, NFormItem, NInput, NInputNumber,
    NGrid, NGi, NAffix,
} from 'naive-ui';
import CardVue from '@/components/Card.vue';
import { useRouter } from 'vue-router';


// 初始化合约以及连接MetaMask
const contract = require('@truffle/contract')
const voting = require('../assets/contracts/Voting.json')
const VotingContract = contract(voting);
VotingContract.setProvider(window.ethereum)


/*************************** comissions相关 *******************************/
const votings = ref([])
const loadPostedData = () => {
  VotingContract.deployed().then((instance) => {
    let res = instance.getAllVotes.call(false);
    // console.log(res)
    return res

  }).then((response) => {
    // console.log(response)
    votings.value.length = 0
    for (let i = 0; i < response.length; i++) {
      let comission = response[i]
      let date = new Date(comission.endTime * 1000)

      let formattedDate = date.toISOString().slice(0, 19).replace('T', ' ')
      votings.value.push({
        title:comission.title,
        isEnded:comission.isEnded,
        reward:comission.reward,
        endTime:formattedDate,
        description:comission.description,
        initator:comission.initator,
        maxParticipants:comission.maxParticipants,
        voteId:comission.voteId,
        candidates:comission.candidates,
        participantCount:comission.participantCount,
        img: '../assets/logo.png',



      })
    }
  }).catch((err) => {
      console.log(err.message);
  });
}
loadPostedData()
/*************************** end comissions *******************************/


/*************************** post相关 *******************************/
const postModalFlag = ref(false)
const post_comission = reactive({})
const init_post_comission = () => {
    post_comission.title = '',
        post_comission.description = '',
        post_comission.reward = 10,//ETH
        post_comission.maxParticipants = 10,
        post_comission.duration = 86400 //one day
}
init_post_comission()

const showPostModal = () => {
    // 这里追求方便以时间戳为id，后续可改成别的API获取唯一id
    post_comission.id = Date.now()
    postModalFlag.value = post_comission.reward
}

const postSubmit = () => {
    VotingContract.deployed().then(async (instance) => {
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
        const account = await accounts[0]
        // console.log("post_comission")
        instance.initiateVote(
            post_comission.title, post_comission.description, post_comission.duration,
            post_comission.maxParticipants, Web3.utils.toWei(post_comission.reward.toString(), 'ether'), { from: account,value: Web3.utils.toWei(post_comission.reward.toString(), 'ether') }
        )

    }).then((response) => {
        init_post_comission()
        loadPostedData()
        postModalFlag.value = false
    }).catch((err) => {
        alert('error', err.message)
        console.log(err.message);
    });
}
/*************************** end post *******************************/

const router = useRouter();
/*************************** purchase相关 *******************************/
const purchase = (comission) => {
    router.push({ name: 'vote', params: { id: comission.voteId }})
    // ArtComissionContract.deployed().then(async (instance) => {
    //     const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
    //     const account = await accounts[0]
    //     return instance.purchase(id, { from: account, value: (price * 1e12) })
    // }).then((response) => {
    //     loadPostedData()
    // }).catch((err) => {
    //     alert('error', err.message)
    //     console.log(err.message);
    // });
}
/*************************** end purchase *******************************/

</script>

<style scoped>
.carousel-container {
    margin: 0 10%;
    padding: 1% 1%;
    background-color: honeydew;
    border-radius: 15px;
}

.carousel {
    width: 100%;
    border-radius: 15px;
}

.carousel-img {
    margin: 0 auto;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.post-container {}

.post-button {
    position: fixed;
    padding: 30px;
    right: 40px;
    bottom: 40px;
    z-index: 1;
}

.modal {
    width: 600px;
}

.form {
    width: 600px;
}

.content-container {
    position: relative;
    min-height: 50vh;
    margin-top: 5vh;
    padding: 1% 5%;
    background-color: white;
    border-radius: 15px;
}
</style>



<template>
  <n-page>
    <n-page-header class="page-header" title="Vote Detail" subtitle="View and participate in the vote">

    </n-page-header>
    <n-card>
      <n-space vertical>
        <n-text>Vote ID: {{ voteInfo.voteId }}</n-text>
        <n-text>Title: {{ voteInfo.title }}</n-text>
        <n-text>Is Ended: {{ voteInfo.isEnded }}</n-text>
        <n-text>Reward: {{ voteInfo.reward }} ETH</n-text>
        <n-text>End Time: {{ voteInfo.endTime }}</n-text>
        <n-text>Description: {{ voteInfo.description }}</n-text>
        <n-text>Initiator: {{ voteInfo.initiator }}</n-text>
        <n-text>Max Participants: {{ voteInfo.maxParticipants }}</n-text>
        <n-text >Participant Count: {{ voteInfo.participantCount }}</n-text>
        <n-avatar :src="voteInfo.img" size="large">
          
        </n-avatar>
        <n-button type="primary" @click="joinVote">Join</n-button>
      </n-space>
    </n-card>
    <n-list bordered>
      <template #header>
        <n-h3>Participants</n-h3>
      </template>
      <n-list-item v-for="candidate in voteInfo.candidates" :key="candidate">
        <n-card>
          <n-space justify="space-between">
            <n-text >{{ candidate }} - {{ candidateVotes[candidate] }} votes</n-text>
            <n-button type="success" @click="vote(candidate)">Vote</n-button>

          </n-space>
        </n-card>
      </n-list-item>
    </n-list>
  </n-page>
</template>

<script>
import { defineComponent, ref, onMounted } from 'vue';
import Web3 from 'web3';
import { useRoute } from 'vue-router';
import { NPage, NPageHeader, NCard, NSpace, NText, NAvatar, NButton, NList, NListItem } from 'naive-ui';
import { getCurrentInstance } from 'vue';


export default defineComponent({
  name: 'VoteDetail',
  components: {
    NPage,
    NPageHeader,
    NCard,
    NSpace,
    NText,
    NAvatar,
    NButton,
    NList,
    NListItem
  },
  setup() {
    const route = useRoute();
    const voteId = route.params.id;
    const voteInfo = ref({
      title: '',
      isEnded: false,
      reward: '',
      endTime: '',
      description: '',
      initiator: '',
      maxParticipants: 0,
      voteId: '',
      candidates: [],
      participantCount: 0,
      img: '../assets/logo.png'
    });
    const candidateVotes = ref({});
    const votes={}

    const contract = require('@truffle/contract')
    const voting = require('../assets/contracts/Voting.json')
    const VotingContract = contract(voting);
    VotingContract.setProvider(window.ethereum)

    const methodThatForcesUpdate = () => {
      const instance = getCurrentInstance();
      instance.proxy.$forceUpdate();
    };


    const fetchVoteInfo = async () => {
      VotingContract.deployed().then((instance) => {
        let res = instance.getVote.call(voteId);
        // console.log(res)
        return res

      }).then((vote) => {
        let date = new Date(vote.endTime * 1000)

        let formattedDate = date.toISOString().slice(0, 19).replace('T', ' ')
        voteInfo.value = {
          title: vote.title,
          isEnded: vote.isEnded,
          reward: Web3.utils.fromWei(vote.reward, 'ether'),
          endTime: formattedDate,
          description: vote.description,
          initiator: vote.initiator,
          maxParticipants: vote.maxParticipants,
          voteId: vote.voteId,
          candidates: vote.candidates,
          participantCount: vote.participantCount,
          img: '../assets/logo.png',
          
        };
        for(let i=0;i<vote.candidates.length;i++){
          VotingContract.deployed().then((instance) => {
            let res = instance.getVotes.call(voteId, vote.candidates[i]);
            return res

          }).then((response) => {
            votes[vote.candidates[i]]=response
          }).catch((err) => {
            console.error("Error fetching vote info:", err);
          });
        }
        candidateVotes.value=votes
        // console.log(candidateVotes)

        
        // console.log(voteInfo)
      }).catch((err) => {
        console.error("Error fetching vote info:", err);
      });
      
    }

    const vote = async (candidate) => {
      // try {
      //   const accounts = await web3.eth.getAccounts();
      //   await contract.methods.vote(voteId, candidate).send({ from: accounts[0] });
      //   fetchVoteInfo(); // Refresh vote info
      // } catch (error) {
      //   console.error("Error voting:", error);
      // }
      VotingContract.deployed().then(async (instance) => {
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
        const account = await accounts[0]

        instance.vote(
          voteId, candidate, { from: account }
        )

      }).then((response) => {
        fetchVoteInfo();
        methodThatForcesUpdate()
      }).catch((err) => {
        // alert('error', err.message)
        console.log(err.message);
      });
    };

    const joinVote = async () => {
      VotingContract.deployed().then(async (instance) => {
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' })
        const account = await accounts[0]

        instance.addCandidate(
          voteId, { from: account, value: Web3.utils.toWei('1', 'ether') }
        )

      }).then((response) => {
        fetchVoteInfo();
        methodThatForcesUpdate()
      }).catch((err) => {
        // alert('error', err.message)
        console.log(err.message);
      });

    };

    onMounted(() => {
      fetchVoteInfo();
    });



    return {
      candidateVotes,
      voteInfo,
      vote,
      joinVote
    };
  }
});
</script>

<style scoped>
.page-header{
  margin: 0 1%;
  padding: 0% 0% 1% 0%;
}
/* Your styles here */
</style>

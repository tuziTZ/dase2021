# BlockChainFinalDemo
BlockChain Final Project Demo, use Vue + NaiveUI + truffle

install nodejs + npm



install truffle

```shell
npm install -g truffle
```

Launch truffle server. You should quick start Ganach first.

```shell
cd dserver
truffle migrate
```

Launch vue client

```shell
cd dclient
npm install
bash migrate.sh // this use to copy contracts.json from dserver to dclient you should use it after truffle migrate
npm run serve
```

Then you can open the browsite use MetaMask to connect this!

https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd?pli=1

**Warning: Be sure to copy dserver/build/contracts/*! Or use migrate.sh**
